const express = require("express");
const Item = require("../models/Item");
const authMiddleware = require("../middleware/authMiddleware");
const { analyzeImage } = require("../services/aiVision");
const { rankCandidates, explainMatch } = require("../services/matching");

const router = express.Router();


// ==========================================
// CREATE LOST / FOUND ITEM
// ==========================================
router.post("/", authMiddleware, async (req, res) => {
  try {
    const {
      type,
      title,
      category,
      color,
      brand,
      distinguishingMarks,
      description,
      imageUrl,
      location,
      date,
      rewardAmount,
    } = req.body;

    // Only the fields above are accepted from the request body. In
    // particular, reportedBy is always taken from the authenticated JWT.
    const requiredFields = { type, title, location, date };
    const missingFields = Object.entries(requiredFields)
      .filter(([, value]) =>
        value === undefined || value === null || String(value).trim() === ""
      )
      .map(([field]) => field);

    if (missingFields.length > 0) {
      return res.status(400).json({
        message: "Missing required fields",
        fields: missingFields,
      });
    }

    if (!["lost", "found"].includes(type)) {
      return res.status(400).json({
        message: "type must be either 'lost' or 'found'",
      });
    }

    if (Number.isNaN(new Date(date).getTime())) {
      return res.status(400).json({
        message: "date must be a valid date",
      });
    }

    const item = await Item.create({
      type,
      title,
      category,
      color,
      brand,
      distinguishingMarks,
      description,
      imageUrl,
      location,
      date,
      rewardAmount,
      reportedBy: req.user.id,
    });

    res.status(201).json({
      message: "Item created successfully",
      item,
    });

  } catch (error) {
    console.error("Create item error:", error);

    res.status(500).json({
      message: "Server error",
      error: error.message,
    });
  }
});


// ==========================================
// GET / SEARCH ITEMS
// ==========================================
router.get("/", async (req, res) => {
  try {
    const {
      type,
      category,
      location,
      status,
      search,
    } = req.query;

    const filter = {};

    if (type) {
      filter.type = type;
    }

    if (category) {
      filter.category = {
        $regex: category,
        $options: "i",
      };
    }

    if (location) {
      filter.location = {
        $regex: location,
        $options: "i",
      };
    }

    if (status) {
      filter.status = status;
    }

    if (search) {
      filter.$or = [
        {
          title: {
            $regex: search,
            $options: "i",
          },
        },
        {
          description: {
            $regex: search,
            $options: "i",
          },
        },
        {
          category: {
            $regex: search,
            $options: "i",
          },
        },
        {
          brand: {
            $regex: search,
            $options: "i",
          },
        },
      ];
    }

    const items = await Item.find(filter)
      .populate("reportedBy", "name email")
      .sort({ createdAt: -1 });

    res.json({
      count: items.length,
      items,
    });

  } catch (error) {
    console.error("Search items error:", error);

    res.status(500).json({
      message: "Server error",
      error: error.message,
    });
  }
});


// ==========================================
// GET SINGLE ITEM
// ==========================================
router.get("/:id", async (req, res) => {
  try {
    const item = await Item.findById(req.params.id)
      .populate("reportedBy", "name email");

    if (!item) {
      return res.status(404).json({
        message: "Item not found",
      });
    }

    res.json({
      item,
    });

  } catch (error) {
    console.error("Get item error:", error);

    res.status(500).json({
      message: "Server error",
      error: error.message,
    });
  }
});


// ==========================================
// AI ANALYZE ITEM PHOTO
// POST /api/items/:id/analyze  (owner only)
// ==========================================
// Runs the uploaded photo through Groq vision, stores the structured
// result on item.aiAnalysis, and auto-fills any of category/color/
// brand/distinguishingMarks/description the reporter left blank.
// Never overwrites a field the human already typed.
router.post("/:id/analyze", authMiddleware, async (req, res) => {
  try {
    const item = await Item.findById(req.params.id);

    if (!item) {
      return res.status(404).json({ message: "Item not found" });
    }

    if (item.reportedBy.toString() !== req.user.id) {
      return res.status(403).json({
        message: "You can only run AI analysis on your own items",
      });
    }

    if (!item.imageUrl) {
      return res.status(400).json({
        message: "This item has no photo to analyze",
      });
    }

    const analysis = await analyzeImage(item.imageUrl);

    item.aiAnalysis = analysis;
    if (analysis.ok) {
      if (!item.category && analysis.category) item.category = analysis.category;
      if (!item.color && analysis.color) item.color = analysis.color;
      if (!item.brand && analysis.brand) item.brand = analysis.brand;
      if (!item.distinguishingMarks && analysis.distinguishingMarks) {
        item.distinguishingMarks = analysis.distinguishingMarks;
      }
      if (!item.description && analysis.description) item.description = analysis.description;
    }

    await item.save();

    res.json({
      message: analysis.ok ? "AI analysis complete" : "AI analysis unavailable",
      item,
    });
  } catch (error) {
    console.error("Analyze item error:", error);

    res.status(500).json({
      message: "Server error",
      error: error.message,
    });
  }
});

// ==========================================
// AI MATCHES FOR ITEM
// GET /api/items/:id/matches
// ==========================================
// Ranks every OPEN report of the opposite type (lost<->found) already
// on this platform against this item, using AI-derived + human-entered
// attributes, then asks the AI for a short plain-English reason for
// the top few. This is the "AI automatically looks for who it belongs
// to" feature, scoped to LostFound+'s own database.
router.get("/:id/matches", async (req, res) => {
  try {
    const item = await Item.findById(req.params.id);

    if (!item) {
      return res.status(404).json({ message: "Item not found" });
    }

    const oppositeType = item.type === "lost" ? "found" : "lost";

    const pool = await Item.find({
      type: oppositeType,
      status: "open",
      _id: { $ne: item._id },
    })
      .populate("reportedBy", "name email")
      .limit(200);

    const ranked = rankCandidates(item, pool, 8);

    const explainCount = Math.min(3, ranked.length);
    const matches = await Promise.all(
      ranked.map(async (m, i) => ({
        item: m.candidate,
        score: m.score,
        reasons: m.reasons,
        aiExplanation:
          i < explainCount ? await explainMatch(item, m.candidate, m.reasons) : null,
      })),
    );

    res.json({ count: matches.length, matches });
  } catch (error) {
    console.error("Get matches error:", error);

    res.status(500).json({
      message: "Server error",
      error: error.message,
    });
  }
});

// ==========================================
// UPDATE ITEM
// ==========================================
router.put("/:id", authMiddleware, async (req, res) => {
  try {
    const item = await Item.findById(req.params.id);

    if (!item) {
      return res.status(404).json({
        message: "Item not found",
      });
    }

    // Check ownership
    if (item.reportedBy.toString() !== req.user.id) {
      return res.status(403).json({
        message: "You can only update your own items",
      });
    }

    // Fields that can be updated
    const allowedFields = [
      "type",
      "title",
      "category",
      "color",
      "brand",
      "distinguishingMarks",
      "description",
      "imageUrl",
      "location",
      "date",
      "rewardAmount",
      "status",
    ];

    allowedFields.forEach((field) => {
      if (req.body[field] !== undefined) {
        item[field] = req.body[field];
      }
    });

    await item.save();

    res.json({
      message: "Item updated successfully",
      item,
    });

  } catch (error) {
    console.error("Update item error:", error);

    res.status(500).json({
      message: "Server error",
      error: error.message,
    });
  }
});


// ==========================================
// DELETE ITEM
// ==========================================
router.delete("/:id", authMiddleware, async (req, res) => {
  try {
    const item = await Item.findById(req.params.id);

    if (!item) {
      return res.status(404).json({
        message: "Item not found",
      });
    }

    // Check ownership
    if (item.reportedBy.toString() !== req.user.id) {
      return res.status(403).json({
        message: "You can only delete your own items",
      });
    }

    await Item.findByIdAndDelete(req.params.id);

    res.json({
      message: "Item deleted successfully",
    });

  } catch (error) {
    console.error("Delete item error:", error);

    res.status(500).json({
      message: "Server error",
      error: error.message,
    });
  }
});


module.exports = router;
