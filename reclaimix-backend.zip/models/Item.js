const mongoose = require("mongoose");

const itemSchema = new mongoose.Schema(
    {
        type: {
            type: String,
            enum: ["lost", "found"],
            required: true,
        },

        title: {
            type: String,
            required: true,
            trim: true,
        },

        category: {
            type: String,
            default: "",
        },

        color: {
            type: String,
            default: "",
        },

        brand: {
            type: String,
            default: "",
        },

        distinguishingMarks: {
            type: String,
            default: "",
        },

        description: {
            type: String,
            default: "",
        },

        imageUrl: {
            type: String,
            default: "",
        },

        location: {
            type: String,
            required: true,
        },

        date: {
            type: Date,
            required: true,
        },

        rewardAmount: {
            type: Number,
            default: 0,
        },

        status: {
            type: String,
            enum: ["open", "matched", "claimed", "resolved"],
            default: "open",
        },

        claimedBy: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },

        claimStatus: {
            type: String,
            enum: ["none", "pending", "approved", "rejected"],
            default: "none",
        },

        reportedBy: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: true,
        },

        aiAnalysis: {
            type: mongoose.Schema.Types.Mixed,
            default: null,
        },
    },
    {
        timestamps: true,
    }
);

module.exports = mongoose.model("Item", itemSchema);