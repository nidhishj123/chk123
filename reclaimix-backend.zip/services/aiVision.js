// ================================================================
// AI VISION SERVICE
// ================================================================
// Uses Groq's hosted vision model to look at an uploaded item photo
// and turn it into structured, searchable attributes. This is what
// powers "AI auto-fill" on report creation and feeds the matching
// engine in services/matching.js.
//
// IMPORTANT: Groq's multimodal model lineup changes frequently and
// models get deprecated. If you get a "model not found" / 400 error,
// check https://console.groq.com/docs/vision for the current vision
// model id and update GROQ_VISION_MODEL below (or set it in .env).
// ================================================================

const Groq = require("groq-sdk");

const VISION_MODEL = process.env.GROQ_VISION_MODEL || "qwen/qwen3.6-27b";

// Lazy client: constructing Groq() throws immediately if GROQ_API_KEY is
// missing, which would otherwise crash the whole server at require-time
// (routes/items.js requires this file). Build it on first real use instead,
// so a missing/rotated key just disables AI features instead of taking the
// whole API down.
let _groq = null;
function client() {
  if (!_groq) _groq = new Groq({ apiKey: process.env.GROQ_API_KEY });
  return _groq;
}

const SYSTEM_PROMPT = `You are an item-identification assistant for a lost-and-found platform.
You will be shown a photo of a physical object that someone lost or found (never a person).
Describe the object for the purpose of matching it against other reports.

Reply with ONLY valid JSON (no markdown, no commentary) in exactly this shape:
{
  "category": "one short word, e.g. Electronics, Watch, Bag, Keys, Jewelry, Clothing, Documents, Wallet, Other",
  "color": "primary color(s), short",
  "brand": "brand or model if visible or confidently inferable, else empty string",
  "distinguishingMarks": "scratches, stickers, engravings, wear, straps, anything unique you can see",
  "description": "one or two plain sentences describing the item",
  "tags": ["5 to 10 short lowercase keywords useful for search matching"]
}`;

/**
 * Analyze an item photo (by public URL, e.g. a Cloudinary URL) and return
 * structured attributes. Never throws — on any failure it returns a
 * clearly-marked empty result so callers can degrade gracefully instead of
 * breaking the report flow.
 */
async function analyzeImage(imageUrl) {
  if (!imageUrl) {
    return emptyResult("No image URL provided");
  }
  if (!process.env.GROQ_API_KEY) {
    return emptyResult("GROQ_API_KEY is not set");
  }

  try {
    const completion = await client().chat.completions.create({
      model: VISION_MODEL,
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        {
          role: "user",
          content: [
            { type: "text", text: "Analyze this item photo and return the JSON described." },
            { type: "image_url", image_url: { url: imageUrl } },
          ],
        },
      ],
      temperature: 0.2,
      max_completion_tokens: 500,
      response_format: { type: "json_object" },
    });

    const raw = completion.choices?.[0]?.message?.content || "{}";
    const parsed = JSON.parse(raw);

    return {
      ok: true,
      category: String(parsed.category || "").slice(0, 40),
      color: String(parsed.color || "").slice(0, 40),
      brand: String(parsed.brand || "").slice(0, 60),
      distinguishingMarks: String(parsed.distinguishingMarks || "").slice(0, 300),
      description: String(parsed.description || "").slice(0, 500),
      tags: Array.isArray(parsed.tags) ? parsed.tags.map(String).slice(0, 10) : [],
      model: VISION_MODEL,
      analyzedAt: new Date().toISOString(),
    };
  } catch (error) {
    console.error("AI vision analysis failed:", error.message);
    return emptyResult(error.message);
  }
}

function emptyResult(reason) {
  return {
    ok: false,
    reason,
    category: "",
    color: "",
    brand: "",
    distinguishingMarks: "",
    description: "",
    tags: [],
    model: VISION_MODEL,
    analyzedAt: new Date().toISOString(),
  };
}

module.exports = { analyzeImage, VISION_MODEL };
