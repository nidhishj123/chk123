// ================================================================
// MATCHING ENGINE
// ================================================================
// This is the "AI finds who it belongs to" feature. It searches
// *within LostFound+'s own database* — every lost/found report ever
// submitted on the platform — not external social media. See the
// README for why: scraping people's social profiles for image
// matches isn't something this project does.
//
// Scoring is a deterministic, explainable weighted comparison
// (category / color / brand / text-token overlap / date-and-location
// proximity) so it always works even if the AI text call is down.
// For the top few candidates we then ask Groq for a one-line, plain
// -English reason a human can sanity-check — that call is optional
// and wrapped so its failure never breaks the ranking.
// ================================================================

const Groq = require("groq-sdk");

const TEXT_MODEL = process.env.GROQ_TEXT_MODEL || "openai/gpt-oss-20b";

// See services/aiVision.js for why this is lazy.
let _groq = null;
function client() {
  if (!_groq) _groq = new Groq({ apiKey: process.env.GROQ_API_KEY });
  return _groq;
}

const STOPWORDS = new Set([
  "the", "a", "an", "and", "or", "of", "in", "on", "with", "for", "to", "it",
  "is", "was", "at", "by", "this", "that", "my", "i", "found", "lost", "item",
]);

function tokenize(text) {
  return String(text || "")
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .filter((t) => t.length > 1 && !STOPWORDS.has(t));
}

function jaccard(aTokens, bTokens) {
  const a = new Set(aTokens);
  const b = new Set(bTokens);
  if (a.size === 0 || b.size === 0) return 0;
  let intersection = 0;
  for (const t of a) if (b.has(t)) intersection++;
  const union = a.size + b.size - intersection;
  return union === 0 ? 0 : intersection / union;
}

function fullText(item) {
  const ai = item.aiAnalysis || {};
  return [
    item.title,
    item.description,
    item.distinguishingMarks,
    item.category,
    item.brand,
    ai.description,
    ai.distinguishingMarks,
    Array.isArray(ai.tags) ? ai.tags.join(" ") : "",
  ].join(" ");
}

function fieldOf(item, field) {
  // Prefer what the human typed; fall back to the AI's read of the photo.
  return (item[field] && String(item[field]).trim()) || (item.aiAnalysis && item.aiAnalysis[field]) || "";
}

function daysBetween(a, b) {
  const ms = Math.abs(new Date(a).getTime() - new Date(b).getTime());
  return ms / (1000 * 60 * 60 * 24);
}

/**
 * Score `candidate` (the opposite type: lost<->found) against `target`.
 * Returns { score: 0-100, reasons: string[] } — reasons are the
 * deterministic signals that fired, used as a fallback if the AI
 * explanation call fails or is skipped.
 */
function scorePair(target, candidate) {
  let score = 0;
  const reasons = [];

  const tCategory = fieldOf(target, "category").toLowerCase();
  const cCategory = fieldOf(candidate, "category").toLowerCase();
  if (tCategory && cCategory && tCategory === cCategory) {
    score += 25;
    reasons.push(`Same category (${cCategory})`);
  }

  const tColor = fieldOf(target, "color").toLowerCase();
  const cColor = fieldOf(candidate, "color").toLowerCase();
  if (tColor && cColor && (tColor === cColor || tColor.includes(cColor) || cColor.includes(tColor))) {
    score += 15;
    reasons.push(`Matching color (${cColor})`);
  }

  const tBrand = fieldOf(target, "brand").toLowerCase();
  const cBrand = fieldOf(candidate, "brand").toLowerCase();
  if (tBrand && cBrand && (tBrand === cBrand || tBrand.includes(cBrand) || cBrand.includes(tBrand))) {
    score += 20;
    reasons.push(`Same brand/model (${candidate.brand || cBrand})`);
  }

  const textSim = jaccard(tokenize(fullText(target)), tokenize(fullText(candidate)));
  if (textSim > 0) {
    const pts = Math.round(textSim * 30);
    score += pts;
    if (textSim > 0.15) reasons.push("Overlapping description details");
  }

  const tLoc = String(target.location || "").toLowerCase().trim();
  const cLoc = String(candidate.location || "").toLowerCase().trim();
  if (tLoc && cLoc && (tLoc === cLoc || tLoc.includes(cLoc) || cLoc.includes(tLoc))) {
    score += 5;
    reasons.push(`Reported near the same location (${candidate.location})`);
  }

  if (target.date && candidate.date) {
    const gap = daysBetween(target.date, candidate.date);
    if (gap <= 14) {
      score += 5;
      reasons.push("Reported within 2 weeks of each other");
    }
  }

  return { score: Math.min(100, Math.round(score)), reasons };
}

/**
 * Rank every open item of the opposite type against `target`.
 * `pool` should already be filtered to opposite type + status "open".
 */
function rankCandidates(target, pool, limit = 8) {
  return pool
    .map((candidate) => ({ candidate, ...scorePair(target, candidate) }))
    .filter((m) => m.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);
}

/**
 * Best-effort natural-language reason for one match. Falls back to the
 * deterministic reasons list (joined) if the AI call fails or is
 * unavailable — the feature never hard-fails.
 */
async function explainMatch(target, candidate, fallbackReasons) {
  const fallback = fallbackReasons.length
    ? fallbackReasons.join(". ") + "."
    : "Similar attributes across both reports.";

  if (!process.env.GROQ_API_KEY) return fallback;

  try {
    const completion = await client().chat.completions.create({
      model: TEXT_MODEL,
      messages: [
        {
          role: "system",
          content:
            "You help a lost-and-found site explain, in ONE short sentence (under 25 words), " +
            "why two item reports might be the same object. Be concrete and specific. No preamble.",
        },
        {
          role: "user",
          content: `Report A (${target.type}): ${fullText(target)}\n\nReport B (${candidate.type}): ${fullText(candidate)}`,
        },
      ],
      temperature: 0.3,
      max_completion_tokens: 80,
    });
    const text = completion.choices?.[0]?.message?.content?.trim();
    return text || fallback;
  } catch (error) {
    console.error("AI match explanation failed:", error.message);
    return fallback;
  }
}

module.exports = { rankCandidates, explainMatch, scorePair };
