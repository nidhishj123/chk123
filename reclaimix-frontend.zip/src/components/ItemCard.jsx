import { Link } from "@tanstack/react-router";
import { CalendarDays, MapPin, Tag } from "lucide-react";
import StatusBadge from "./StatusBadge";
import { formatDate } from "@/lib/store";

export default function ItemCard({ item }) {
  return (
    <article className="group flex flex-col overflow-hidden rounded-xl border border-border bg-card shadow-card transition-shadow hover:shadow-card-hover">
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-muted">
        {item.imageUrl ? (
          <img
            src={item.imageUrl}
            alt={item.title}
            loading="lazy"
            className="size-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
          />
        ) : (
          <div className="grid size-full place-items-center text-sm text-muted-foreground">
            No image
          </div>
        )}
        <div className="absolute left-3 top-3 flex gap-2">
          <StatusBadge value={item.type} className="bg-card/95 backdrop-blur" />
        </div>
      </div>

      <div className="flex flex-1 flex-col p-4">
        <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
          <h3 className="truncate text-base font-semibold text-foreground">{item.title}</h3>
          <StatusBadge value={item.status} />
        </div>

        <dl className="mt-3 space-y-1.5 text-sm text-muted-foreground">
          <div className="flex min-w-0 items-center gap-2">
            <Tag className="size-4 shrink-0" />
            <span className="truncate">{item.category || "Uncategorised"}</span>
          </div>
          <div className="flex min-w-0 items-center gap-2">
            <MapPin className="size-4 shrink-0" />
            <span className="truncate">{item.location}</span>
          </div>
          <div className="flex min-w-0 items-center gap-2">
            <CalendarDays className="size-4 shrink-0" />
            <span className="truncate">{formatDate(item.date)}</span>
          </div>
        </dl>

        <Link
          to="/item/$id"
          params={{ id: item.id }}
          className="mt-4 inline-flex w-full items-center justify-center rounded-md border border-border bg-background px-4 py-2 text-sm font-semibold text-foreground transition-colors hover:border-primary/40 hover:bg-primary-soft hover:text-primary"
        >
          View Details
        </Link>
      </div>
    </article>
  );
}
