const TONES = {
  // item.type
  lost: "bg-error-soft text-error border-error/20",
  found: "bg-success-soft text-success border-success/20",
  // item.status
  open: "bg-primary-soft text-primary border-primary/20",
  matched: "bg-pending-soft text-pending border-pending/25",
  claimed: "bg-success-soft text-success border-success/20",
  resolved: "bg-muted text-muted-foreground border-border",
  // item.claimStatus
  none: "bg-muted text-muted-foreground border-border",
  pending: "bg-pending-soft text-pending border-pending/25",
  approved: "bg-success-soft text-success border-success/20",
  rejected: "bg-error-soft text-error border-error/20",
};

export default function StatusBadge({ value, className = "" }) {
  const tone = TONES[String(value).toLowerCase()] ?? TONES.resolved;
  return (
    <span
      className={`inline-flex items-center rounded-md border px-2 py-0.5 text-xs font-semibold capitalize tracking-wide ${tone} ${className}`}
    >
      {value}
    </span>
  );
}
