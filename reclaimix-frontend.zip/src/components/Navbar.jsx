import { useEffect, useState } from "react";
import { Link, useNavigate, useRouter } from "@tanstack/react-router";
import { LogOut, Menu, Search, X } from "lucide-react";
import { getCurrentUser, logoutUser } from "@/lib/store";

const LINKS = [
  { to: "/", label: "Home", exact: true },
  { to: "/search", label: "Find an Item" },
  { to: "/report", label: "Report an Item" },
  { to: "/dashboard", label: "My Dashboard" },
];

function initialsOf(name) {
  if (!name) return "?";
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join("");
}

export default function Navbar() {
  const [open, setOpen] = useState(false);
  // Auth state is read from localStorage, which is browser-only, so we hydrate
  // it after mount to avoid an SSR/client mismatch.
  const [user, setUser] = useState(null);
  const navigate = useNavigate();
  const router = useRouter();

  useEffect(() => {
    setUser(getCurrentUser());
  }, [router.state.location.href]);

  const handleLogout = () => {
    logoutUser();
    setUser(null);
    setOpen(false);
    navigate({ to: "/" });
  };

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-card/90 backdrop-blur">
      <nav className="mx-auto grid max-w-7xl grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-4 py-3 sm:px-6">
        <Link to="/" className="flex min-w-0 items-center gap-2">
          <span className="grid size-9 shrink-0 place-items-center rounded-lg bg-primary text-primary-foreground">
            <Search className="size-4" />
          </span>
          <span className="truncate text-lg font-bold tracking-tight text-foreground">
            LostFound<span className="text-primary">+</span>
          </span>
        </Link>

        <div className="flex shrink-0 items-center gap-1">
          <ul className="hidden items-center gap-1 md:flex">
            {LINKS.map((l) => (
              <li key={l.to}>
                <Link
                  to={l.to}
                  activeOptions={{ exact: l.exact }}
                  activeProps={{ className: "bg-primary-soft text-primary" }}
                  inactiveProps={{ className: "text-muted-foreground hover:bg-muted" }}
                  className="rounded-md px-3 py-2 text-sm font-medium transition-colors"
                >
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>

          {user ? (
            <div className="ml-2 hidden items-center gap-2 border-l border-border pl-3 md:flex">
              <span className="grid size-9 place-items-center rounded-full bg-navy text-sm font-semibold text-primary-foreground">
                {initialsOf(user.name)}
              </span>
              <div className="hidden lg:block">
                <p className="text-sm font-semibold leading-tight text-foreground">{user.name}</p>
                <p className="truncate text-xs leading-tight text-muted-foreground">{user.email}</p>
              </div>
              <button
                type="button"
                onClick={handleLogout}
                aria-label="Log out"
                className="grid size-8 shrink-0 place-items-center rounded-md text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
              >
                <LogOut className="size-4" />
              </button>
            </div>
          ) : (
            <div className="ml-2 hidden items-center gap-2 border-l border-border pl-3 md:flex">
              <Link
                to="/login"
                className="rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted"
              >
                Sign in
              </Link>
              <Link
                to="/register"
                className="rounded-md bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
              >
                Sign up
              </Link>
            </div>
          )}

          <button
            type="button"
            aria-label="Toggle navigation menu"
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
            className="grid size-10 place-items-center rounded-md border border-border text-foreground transition-colors hover:bg-muted md:hidden"
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
      </nav>

      {open ? (
        <div className="border-t border-border bg-card md:hidden">
          <ul className="mx-auto max-w-7xl space-y-1 px-4 py-3">
            {LINKS.map((l) => (
              <li key={l.to}>
                <Link
                  to={l.to}
                  activeOptions={{ exact: l.exact }}
                  onClick={() => setOpen(false)}
                  activeProps={{ className: "bg-primary-soft text-primary" }}
                  inactiveProps={{ className: "text-muted-foreground" }}
                  className="block rounded-md px-3 py-2.5 text-sm font-medium"
                >
                  {l.label}
                </Link>
              </li>
            ))}
            {user ? (
              <>
                <li className="mt-2 flex items-center gap-3 border-t border-border px-3 pt-3">
                  <span className="grid size-9 shrink-0 place-items-center rounded-full bg-navy text-sm font-semibold text-primary-foreground">
                    {initialsOf(user.name)}
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold text-foreground">{user.name}</p>
                    <p className="truncate text-xs text-muted-foreground">{user.email}</p>
                  </div>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={handleLogout}
                    className="mt-1 flex w-full items-center gap-2 rounded-md px-3 py-2.5 text-sm font-medium text-error hover:bg-error-soft"
                  >
                    <LogOut className="size-4" /> Log out
                  </button>
                </li>
              </>
            ) : (
              <li className="mt-2 flex gap-2 border-t border-border px-3 pt-3">
                <Link
                  to="/login"
                  onClick={() => setOpen(false)}
                  className="flex-1 rounded-md border border-border px-3 py-2 text-center text-sm font-semibold text-foreground"
                >
                  Sign in
                </Link>
                <Link
                  to="/register"
                  onClick={() => setOpen(false)}
                  className="flex-1 rounded-md bg-primary px-3 py-2 text-center text-sm font-semibold text-primary-foreground"
                >
                  Sign up
                </Link>
              </li>
            )}
          </ul>
        </div>
      ) : null}
    </header>
  );
}
