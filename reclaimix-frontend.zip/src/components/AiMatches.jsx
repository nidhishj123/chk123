import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Loader2, Mail, Sparkles, TriangleAlert } from "lucide-react";
import { analyzeItem, formatDate, getCurrentUser, getMatches } from "@/lib/store";

function ScoreRing({ score }) {
  const tone =
    score >= 70 ? "text-success" : score >= 40 ? "text-primary" : "text-muted-foreground";
  return (
    <div className={`flex shrink-0 flex-col items-center justify-center ${tone}`}>
      <span className="text-2xl font-bold leading-none">{score}%</span>
      <span className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
        match
      </span>
    </div>
  );
}

function buildMailto(sourceItem, matchItem) {
  const to = matchItem.reportedBy?.email ?? "";
  const subject = `LostFound+ possible match: ${sourceItem.title} ↔ ${matchItem.title}`;
  const body = [
    `Hi, I think our reports on LostFound+ might be a match.`,
    ``,
    `My ${sourceItem.type} report: "${sourceItem.title}" (${sourceItem.id})`,
    `Your ${matchItem.type} report: "${matchItem.title}" (${matchItem.id})`,
    ``,
    `Could we compare details to confirm?`,
  ].join("\n");
  return `mailto:${to}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

/**
 * Shows AI-derived matches for an item, sourced entirely from other
 * reports already on LostFound+ (never external sites or social media).
 *
 * Props:
 *  - item: the item to find matches for (must have `.id` and `.type`)
 *  - isOwner: whether the current user reported this item (enables the
 *    "Analyze with AI" trigger for items that haven't been analyzed yet)
 *  - autoAnalyze: run analysis immediately on mount if not already done
 *    (used right after a report is submitted, for the "wow" moment)
 *  - onItemUpdated: called with the refreshed item after analysis
 */
export default function AiMatches({ item, isOwner = false, autoAnalyze = false, onItemUpdated }) {
  const [analyzing, setAnalyzing] = useState(false);
  const [analyzeError, setAnalyzeError] = useState("");
  const [matches, setMatches] = useState(null);
  const [loadingMatches, setLoadingMatches] = useState(false);
  const currentUser = getCurrentUser();

  const hasAnalysis = Boolean(item?.aiAnalysis);

  const loadMatches = async (targetId) => {
    setLoadingMatches(true);
    try {
      const data = await getMatches(targetId);
      setMatches(data);
    } catch {
      setMatches([]);
    } finally {
      setLoadingMatches(false);
    }
  };

  const runAnalysis = async () => {
    if (!item?.id || !item.imageUrl) return;
    setAnalyzing(true);
    setAnalyzeError("");
    try {
      const updated = await analyzeItem(item.id);
      onItemUpdated?.(updated);
      await loadMatches(updated.id);
    } catch (err) {
      setAnalyzeError(err.message || "AI analysis failed.");
    } finally {
      setAnalyzing(false);
    }
  };

  useEffect(() => {
    if (!item?.id) return;
    if (hasAnalysis) {
      loadMatches(item.id);
    } else if (autoAnalyze && isOwner && item.imageUrl) {
      runAnalysis();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [item?.id, hasAnalysis]);

  if (!item?.imageUrl) return null;

  return (
    <div className="rounded-2xl border border-border bg-card p-6 shadow-card">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="grid size-9 shrink-0 place-items-center rounded-md bg-primary-soft text-primary">
            <Sparkles className="size-4" />
          </span>
          <div>
            <h2 className="text-base font-semibold text-foreground">AI Match Finder</h2>
            <p className="text-xs text-muted-foreground">
              Scans every {item.type === "lost" ? "found" : "lost"} report already on
              LostFound+ — not external sites or social media.
            </p>
          </div>
        </div>
      </div>

      {!hasAnalysis && isOwner ? (
        <div className="mt-4">
          <button
            type="button"
            onClick={runAnalysis}
            disabled={analyzing}
            className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-60"
          >
            {analyzing ? <Loader2 className="size-4 animate-spin" /> : <Sparkles className="size-4" />}
            {analyzing ? "Analyzing photo…" : "Analyze photo with AI"}
          </button>
          {analyzeError ? (
            <p className="mt-2 flex items-center gap-1.5 text-sm text-error">
              <TriangleAlert className="size-4 shrink-0" /> {analyzeError}
            </p>
          ) : null}
        </div>
      ) : null}

      {!hasAnalysis && !isOwner ? (
        <p className="mt-4 text-sm text-muted-foreground">
          The reporter hasn't run AI analysis on this item yet.
        </p>
      ) : null}

      {hasAnalysis ? (
        <div className="mt-4">
          {item.aiAnalysis?.tags?.length ? (
            <div className="mb-4 flex flex-wrap gap-1.5">
              {item.aiAnalysis.tags.map((tag) => (
                <span
                  key={tag}
                  className="rounded-full bg-muted px-2.5 py-1 text-xs font-medium text-muted-foreground"
                >
                  {tag}
                </span>
              ))}
            </div>
          ) : null}

          {loadingMatches ? (
            <p className="flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="size-4 animate-spin" /> Searching reports…
            </p>
          ) : !matches?.length ? (
            <p className="text-sm text-muted-foreground">
              No likely matches yet — new reports are checked automatically.
            </p>
          ) : (
            <ul className="space-y-3">
              {matches.map((m) => (
                <li
                  key={m.item.id}
                  className="flex gap-3 rounded-xl border border-border bg-background p-3"
                >
                  <div className="size-16 shrink-0 overflow-hidden rounded-lg bg-muted">
                    {m.item.imageUrl ? (
                      <img
                        src={m.item.imageUrl}
                        alt={m.item.title}
                        className="size-full object-cover"
                      />
                    ) : null}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-start justify-between gap-2">
                      <Link
                        to="/item/$id"
                        params={{ id: m.item.id }}
                        className="truncate text-sm font-semibold text-foreground hover:text-primary"
                      >
                        {m.item.title}
                      </Link>
                      <ScoreRing score={m.score} />
                    </div>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      {m.item.location} · {formatDate(m.item.date)}
                    </p>
                    <p className="mt-1.5 text-sm text-foreground">
                      {m.aiExplanation || m.reasons?.join(". ")}
                    </p>
                    {currentUser && m.item.reportedBy?.email ? (
                      <a
                        href={buildMailto(item, m.item)}
                        className="mt-2 inline-flex items-center gap-1.5 text-xs font-semibold text-primary hover:underline"
                      >
                        <Mail className="size-3.5" /> Contact reporter
                      </a>
                    ) : null}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      ) : null}
    </div>
  );
}
