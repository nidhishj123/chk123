import { X } from "lucide-react";
import { CATEGORIES, LOCATIONS, ITEM_STATUSES, ITEM_TYPES } from "@/data/mockData";

const selectClass =
  "w-full rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground outline-none transition-colors focus:border-primary focus:ring-2 focus:ring-primary/20";

function Field({ label, children }) {
  return (
    <div className="min-w-0">
      <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-muted-foreground">
        {label}
      </label>
      {children}
    </div>
  );
}

export default function SearchFilters({ filters, onChange, onClear, activeCount }) {
  const set = (key) => (e) => onChange({ ...filters, [key]: e.target.value });

  return (
    <aside className="rounded-xl border border-border bg-card p-5 shadow-card">
      <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
        <h2 className="truncate text-sm font-semibold text-foreground">Filters</h2>
        <button
          type="button"
          onClick={onClear}
          disabled={!activeCount}
          className="inline-flex shrink-0 items-center gap-1 rounded-md px-2 py-1 text-xs font-semibold text-primary transition-colors hover:bg-primary-soft disabled:cursor-not-allowed disabled:text-muted-foreground disabled:hover:bg-transparent"
        >
          <X className="size-3.5" /> Clear
        </button>
      </div>

      <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-1">
        <Field label="Type">
          <select className={selectClass} value={filters.type} onChange={set("type")}>
            <option value="">All types</option>
            {ITEM_TYPES.map((t) => (
              <option key={t.value} value={t.value}>
                {t.label}
              </option>
            ))}
          </select>
        </Field>

        <Field label="Category">
          <select className={selectClass} value={filters.category} onChange={set("category")}>
            <option value="">All categories</option>
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </Field>

        <Field label="Location">
          <select className={selectClass} value={filters.location} onChange={set("location")}>
            <option value="">All locations</option>
            {LOCATIONS.map((l) => (
              <option key={l} value={l}>
                {l}
              </option>
            ))}
          </select>
        </Field>

        <Field label="Status">
          <select className={selectClass} value={filters.status} onChange={set("status")}>
            <option value="">Any status</option>
            {ITEM_STATUSES.map((s) => (
              <option key={s.value} value={s.value}>
                {s.label}
              </option>
            ))}
          </select>
        </Field>
      </div>
    </aside>
  );
}
