import { useRef, useState } from "react";
import { ImagePlus, RefreshCw, Trash2, UploadCloud } from "lucide-react";

/**
 * Reusable image picker with drag & drop, preview, replace and remove.
 * Emits { preview, fileName } through onChange (data URL — swap for a
 * Cloudinary upload later).
 */
export default function ImageUploader({
  value,
  onChange,
  label = "Item Image",
  hint = "PNG or JPG, up to 5 MB",
  error,
}) {
  const inputRef = useRef(null);
  const [dragging, setDragging] = useState(false);
  const [localError, setLocalError] = useState("");

  const handleFile = (file) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setLocalError("Please select an image file.");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setLocalError("Image must be smaller than 5 MB.");
      return;
    }
    setLocalError("");
    const reader = new FileReader();
    reader.onload = () =>
      onChange({ file, preview: String(reader.result), fileName: file.name });
    reader.readAsDataURL(file);
  };

  const shownError = localError || error;

  return (
    <div>
      <label className="mb-1.5 block text-sm font-medium text-foreground">{label}</label>

      {value?.preview ? (
        <div className="rounded-xl border border-border bg-card p-3">
          <div className="overflow-hidden rounded-lg border border-border bg-muted">
            <img
              src={value.preview}
              alt="Selected upload preview"
              className="h-56 w-full object-contain"
            />
          </div>
          <div className="mt-3 grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
            <p className="truncate text-sm text-muted-foreground">{value.fileName}</p>
            <div className="flex shrink-0 gap-2">
              <button
                type="button"
                onClick={() => inputRef.current?.click()}
                className="inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-3 py-1.5 text-sm font-medium text-foreground transition-colors hover:bg-muted"
              >
                <RefreshCw className="size-4" /> Replace
              </button>
              <button
                type="button"
                onClick={() => onChange(null)}
                className="inline-flex items-center gap-1.5 rounded-md border border-error/30 bg-error-soft px-3 py-1.5 text-sm font-medium text-error transition-colors hover:bg-error/15"
              >
                <Trash2 className="size-4" /> Remove
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div
          role="button"
          tabIndex={0}
          onClick={() => inputRef.current?.click()}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault();
              inputRef.current?.click();
            }
          }}
          onDragOver={(e) => {
            e.preventDefault();
            setDragging(true);
          }}
          onDragLeave={() => setDragging(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragging(false);
            handleFile(e.dataTransfer.files?.[0]);
          }}
          className={`flex cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed px-6 py-10 text-center transition-colors ${
            dragging
              ? "border-primary bg-primary-soft"
              : shownError
                ? "border-error/50 bg-error-soft/40"
                : "border-border bg-card hover:border-primary/50 hover:bg-primary-soft/40"
          }`}
        >
          <span className="grid size-11 place-items-center rounded-full bg-primary-soft text-primary">
            {dragging ? <UploadCloud className="size-5" /> : <ImagePlus className="size-5" />}
          </span>
          <p className="mt-3 text-sm font-medium text-foreground">
            Drag & drop an image, or <span className="text-primary">browse</span>
          </p>
          <p className="mt-1 text-xs text-muted-foreground">{hint}</p>
        </div>
      )}

      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          handleFile(e.target.files?.[0]);
          e.target.value = "";
        }}
      />
      {shownError ? <p className="mt-1.5 text-sm text-error">{shownError}</p> : null}
    </div>
  );
}
