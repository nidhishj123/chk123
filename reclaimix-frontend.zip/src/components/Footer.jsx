import { Link } from "@tanstack/react-router";
import { Search } from "lucide-react";

export default function Footer() {
  return (
    <footer className="mt-20 border-t border-border bg-navy text-slate-300">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:px-6 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <div className="flex items-center gap-2">
            <span className="grid size-9 place-items-center rounded-lg bg-primary text-primary-foreground">
              <Search className="size-4" />
            </span>
            <span className="text-lg font-bold tracking-tight text-white">
              LostFound<span className="text-primary">+</span>
            </span>
          </div>
          <p className="mt-3 max-w-sm text-sm leading-relaxed text-slate-400">
            A campus-wide lost & found platform that connects people who lost something with the
            people who found it — verified, tracked and returned.
          </p>
        </div>

        <div>
          <h3 className="text-sm font-semibold text-white">Platform</h3>
          <ul className="mt-3 space-y-2 text-sm">
            <li>
              <Link to="/search" className="transition-colors hover:text-white">
                Find an Item
              </Link>
            </li>
            <li>
              <Link to="/report" className="transition-colors hover:text-white">
                Report an Item
              </Link>
            </li>
            <li>
              <Link to="/dashboard" className="transition-colors hover:text-white">
                My Dashboard
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h3 className="text-sm font-semibold text-white">Support</h3>
          <ul className="mt-3 space-y-2 text-sm text-slate-400">
            <li>Help desk: Main Block, Room 12</li>
            <li>support@lostfoundplus.app</li>
            <li>Mon – Sat, 9:00 – 17:00</li>
          </ul>
        </div>
      </div>

      <div className="border-t border-white/10">
        <p className="mx-auto max-w-7xl px-4 py-5 text-xs text-slate-500 sm:px-6">
          © 2026 LostFound+. Built as a campus lost & found management system.
        </p>
      </div>
    </footer>
  );
}
