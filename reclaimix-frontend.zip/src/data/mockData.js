// Static reference data for LostFound+.
// Item and user data itself comes from the real backend now (see src/lib/store.js).

export const CATEGORIES = [
  "Electronics",
  "Documents",
  "Bags",
  "Accessories",
  "Clothing",
  "Keys",
  "Other",
];

export const LOCATIONS = [
  "Main Block",
  "Central Library",
  "Computer Lab",
  "Cafeteria",
  "Bus Stop",
  "Sports Ground",
  "Auditorium",
];

// Must match the Item model's `type` enum in the backend (models/Item.js).
export const ITEM_TYPES = [
  { value: "lost", label: "Lost" },
  { value: "found", label: "Found" },
];

// Must match the Item model's `status` enum in the backend.
export const ITEM_STATUSES = [
  { value: "open", label: "Open" },
  { value: "matched", label: "Matched" },
  { value: "claimed", label: "Claimed" },
  { value: "resolved", label: "Resolved" },
];

// Must match the Item model's `claimStatus` enum in the backend.
export const CLAIM_STATUSES = [
  { value: "none", label: "None" },
  { value: "pending", label: "Pending" },
  { value: "approved", label: "Approved" },
  { value: "rejected", label: "Rejected" },
];

// Homepage marketing stats — the backend has no analytics endpoint yet, so
// these stay static. Wire up a real /api/stats endpoint later if needed.
export const PLATFORM_STATS = {
  totalReports: 1248,
  itemsRecovered: 863,
  activeListings: 212,
  successfulClaims: 794,
};
