import { useEffect, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { CheckCircle2, LayoutDashboard, Loader2, LogIn, PackageSearch } from "lucide-react";
import ImageUploader from "@/components/ImageUploader";
import AiMatches from "@/components/AiMatches";
import { CATEGORIES, LOCATIONS } from "@/data/mockData";
import { createItem, isAuthenticated, uploadImage } from "@/lib/store";

export const Route = createFileRoute("/report")({
  head: () => ({
    meta: [
      { title: "Report a Lost or Found Item | LostFound+" },
      {
        name: "description",
        content:
          "Submit a lost or found item report with photos, category, location and contact details.",
      },
      { property: "og:title", content: "Report a Lost or Found Item | LostFound+" },
      {
        property: "og:description",
        content: "Create a lost or found report in under a minute on LostFound+.",
      },
    ],
  }),
  component: ReportItem,
});

const inputClass =
  "w-full rounded-md border border-border bg-background px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none transition-colors focus:border-primary focus:ring-2 focus:ring-primary/20";
const errorClass = "border-error focus:border-error focus:ring-error/20";

function Field({ label, required, error, children, htmlFor }) {
  return (
    <div className="min-w-0">
      <label htmlFor={htmlFor} className="mb-1.5 block text-sm font-medium text-foreground">
        {label} {required ? <span className="text-error">*</span> : null}
      </label>
      {children}
      {error ? <p className="mt-1.5 text-sm text-error">{error}</p> : null}
    </div>
  );
}

const EMPTY = {
  type: "lost",
  title: "",
  category: "",
  color: "",
  brand: "",
  distinguishingMarks: "",
  description: "",
  date: "",
  location: "",
  rewardAmount: "",
};

function ReportItem() {
  const navigate = useNavigate();
  // Auth is only knowable client-side (localStorage), so hydrate after mount.
  const [authChecked, setAuthChecked] = useState(false);
  const [signedIn, setSignedIn] = useState(false);
  const [form, setForm] = useState(EMPTY);
  const [image, setImage] = useState(null);
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState("");
  const [created, setCreated] = useState(null);

  useEffect(() => {
    setSignedIn(isAuthenticated());
    setAuthChecked(true);
  }, []);

  const set = (key) => (e) => {
    setForm((f) => ({ ...f, [key]: e.target.value }));
    setErrors((prev) => ({ ...prev, [key]: "" }));
  };

  const validate = () => {
    const next = {};
    if (!form.title.trim()) next.title = "Item name is required.";
    else if (form.title.trim().length < 3) next.title = "Use at least 3 characters.";
    if (!form.description.trim()) next.description = "A short description is required.";
    else if (form.description.trim().length < 15)
      next.description = "Add a little more detail (15+ characters).";
    if (!form.date) next.date = "Select the date.";
    if (!form.location.trim()) next.location = "Location is required.";
    return next;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const next = validate();
    setErrors(next);
    if (Object.keys(next).length) return;

    setSubmitting(true);
    setSubmitError("");
    try {
      let imageUrl = "";
      if (image?.file) {
        imageUrl = await uploadImage(image.file);
      }

      const item = await createItem({
        type: form.type,
        title: form.title.trim(),
        category: form.category.trim(),
        color: form.color.trim(),
        brand: form.brand.trim(),
        distinguishingMarks: form.distinguishingMarks.trim(),
        description: form.description.trim(),
        imageUrl,
        location: form.location.trim(),
        date: form.date,
        rewardAmount: form.rewardAmount ? Number(form.rewardAmount) : 0,
      });
      setCreated(item);
      if (typeof window !== "undefined") window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (err) {
      setSubmitError(err.message || "Could not submit the report.");
    } finally {
      setSubmitting(false);
    }
  };

  if (!authChecked) return null;

  if (!signedIn) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 sm:px-6">
        <div className="rounded-2xl border border-border bg-card p-8 text-center shadow-card">
          <span className="mx-auto grid size-14 place-items-center rounded-full bg-primary-soft text-primary">
            <LogIn className="size-7" />
          </span>
          <h1 className="mt-5 text-2xl font-bold tracking-tight text-foreground">
            Sign in to report an item
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Reports are linked to your account so you can manage and update them later.
          </p>
          <div className="mt-7 flex flex-col gap-3 sm:flex-row sm:justify-center">
            <Link
              to="/login"
              className="inline-flex items-center justify-center rounded-md bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
            >
              Sign in
            </Link>
            <Link
              to="/register"
              className="inline-flex items-center justify-center rounded-md border border-border bg-background px-5 py-2.5 text-sm font-semibold text-foreground transition-colors hover:bg-muted"
            >
              Create an account
            </Link>
          </div>
        </div>
      </div>
    );
  }

  if (created) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 sm:px-6">
        <div className="rounded-2xl border border-border bg-card p-8 text-center shadow-card">
          <span className="mx-auto grid size-14 place-items-center rounded-full bg-success-soft text-success">
            <CheckCircle2 className="size-7" />
          </span>
          <h1 className="mt-5 text-2xl font-bold tracking-tight text-foreground">
            Report submitted successfully
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Your {created.type} item report is now live on the search board.
          </p>
          <div className="mt-6 rounded-lg border border-border bg-background px-4 py-4">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              Report ID
            </p>
            <p className="mt-1 break-all text-lg font-bold tracking-tight text-primary">
              {created.id}
            </p>
          </div>

          {created.imageUrl ? (
            <div className="mt-6 text-left">
              <AiMatches item={created} isOwner autoAnalyze onItemUpdated={setCreated} />
            </div>
          ) : null}

          <div className="mt-7 flex flex-col gap-3 sm:flex-row sm:justify-center">
            <Link
              to="/dashboard"
              className="inline-flex items-center justify-center gap-2 rounded-md bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
            >
              <LayoutDashboard className="size-4" /> Go to My Dashboard
            </Link>
            <Link
              to="/item/$id"
              params={{ id: created.id }}
              className="inline-flex items-center justify-center rounded-md border border-border bg-background px-5 py-2.5 text-sm font-semibold text-foreground transition-colors hover:bg-muted"
            >
              View Report
            </Link>
            <button
              type="button"
              onClick={() => {
                setCreated(null);
                setForm(EMPTY);
                setImage(null);
              }}
              className="inline-flex items-center justify-center rounded-md border border-border bg-background px-5 py-2.5 text-sm font-semibold text-foreground transition-colors hover:bg-muted"
            >
              Submit Another
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 lg:py-14">
      <header className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Report an Item</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Add as much detail as you can — accurate descriptions dramatically improve the chance of
          a match.
        </p>
      </header>

      <form
        onSubmit={handleSubmit}
        noValidate
        className="space-y-6 rounded-2xl border border-border bg-card p-6 shadow-card sm:p-8"
      >
        <fieldset>
          <legend className="mb-3 text-sm font-medium text-foreground">
            What are you reporting? <span className="text-error">*</span>
          </legend>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {[
              { value: "lost", label: "I lost something" },
              { value: "found", label: "I found something" },
            ].map((t) => (
              <button
                key={t.value}
                type="button"
                aria-pressed={form.type === t.value}
                onClick={() => setForm((f) => ({ ...f, type: t.value }))}
                className={`flex items-center gap-3 rounded-lg border px-4 py-3 text-left transition-colors ${
                  form.type === t.value
                    ? "border-primary bg-primary-soft"
                    : "border-border bg-background hover:bg-muted"
                }`}
              >
                <span
                  className={`grid size-9 shrink-0 place-items-center rounded-md ${
                    form.type === t.value
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted text-muted-foreground"
                  }`}
                >
                  <PackageSearch className="size-4" />
                </span>
                <span className="min-w-0">
                  <span className="block text-sm font-semibold text-foreground">
                    {t.value.toUpperCase()} ITEM
                  </span>
                  <span className="block text-xs text-muted-foreground">{t.label}</span>
                </span>
              </button>
            ))}
          </div>
        </fieldset>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
          <Field label="Item Name" required error={errors.title} htmlFor="title">
            <input
              id="title"
              className={`${inputClass} ${errors.title ? errorClass : ""}`}
              placeholder="e.g. Black iPhone 13"
              value={form.title}
              onChange={set("title")}
              maxLength={80}
            />
          </Field>

          <Field label="Category" htmlFor="category">
            <input
              id="category"
              list="category-options"
              className={inputClass}
              placeholder="e.g. Electronics"
              value={form.category}
              onChange={set("category")}
            />
            <datalist id="category-options">
              {CATEGORIES.map((c) => (
                <option key={c} value={c} />
              ))}
            </datalist>
          </Field>
        </div>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-3">
          <Field label="Color" htmlFor="color">
            <input
              id="color"
              className={inputClass}
              placeholder="e.g. Black"
              value={form.color}
              onChange={set("color")}
            />
          </Field>
          <Field label="Brand" htmlFor="brand">
            <input
              id="brand"
              className={inputClass}
              placeholder="e.g. Apple"
              value={form.brand}
              onChange={set("brand")}
            />
          </Field>
          <Field label="Reward (optional)" htmlFor="rewardAmount">
            <input
              id="rewardAmount"
              type="number"
              min="0"
              className={inputClass}
              placeholder="0"
              value={form.rewardAmount}
              onChange={set("rewardAmount")}
            />
          </Field>
        </div>

        <Field label="Distinguishing marks" htmlFor="distinguishingMarks">
          <input
            id="distinguishingMarks"
            className={inputClass}
            placeholder="Scratches, stickers, engravings…"
            value={form.distinguishingMarks}
            onChange={set("distinguishingMarks")}
          />
        </Field>

        <Field label="Description" required error={errors.description} htmlFor="description">
          <textarea
            id="description"
            rows={4}
            maxLength={600}
            className={`${inputClass} resize-y ${errors.description ? errorClass : ""}`}
            placeholder="Colour, brand, marks, contents, anything that helps identify it…"
            value={form.description}
            onChange={set("description")}
          />
        </Field>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
          <Field
            label={`Date ${form.type === "lost" ? "Lost" : "Found"}`}
            required
            error={errors.date}
            htmlFor="date"
          >
            <input
              id="date"
              type="date"
              className={`${inputClass} ${errors.date ? errorClass : ""}`}
              value={form.date}
              onChange={set("date")}
            />
          </Field>

          <Field label="Location" required error={errors.location} htmlFor="location">
            <input
              id="location"
              list="location-options"
              className={`${inputClass} ${errors.location ? errorClass : ""}`}
              placeholder="e.g. Central Library"
              value={form.location}
              onChange={set("location")}
            />
            <datalist id="location-options">
              {LOCATIONS.map((l) => (
                <option key={l} value={l} />
              ))}
            </datalist>
          </Field>
        </div>

        <ImageUploader value={image} onChange={setImage} />

        {submitError ? <p className="text-sm text-error">{submitError}</p> : null}

        <div className="flex flex-col gap-3 border-t border-border pt-6 sm:flex-row sm:justify-end">
          <button
            type="button"
            onClick={() => navigate({ to: "/search" })}
            className="inline-flex items-center justify-center rounded-md border border-border bg-background px-5 py-2.5 text-sm font-semibold text-foreground transition-colors hover:bg-muted"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={submitting}
            className="inline-flex items-center justify-center gap-2 rounded-md bg-primary px-6 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-60"
          >
            {submitting ? <Loader2 className="size-4 animate-spin" /> : null}
            Submit Report
          </button>
        </div>
      </form>
    </div>
  );
}
