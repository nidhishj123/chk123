import { useEffect, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import {
  ArrowLeft,
  CalendarDays,
  Coins,
  Hash,
  Loader2,
  MapPin,
  PackageSearch,
  Palette,
  ShieldCheck,
  Tag,
  Trash2,
  UserRound,
} from "lucide-react";
import StatusBadge from "@/components/StatusBadge";
import EmptyState from "@/components/EmptyState";
import AiMatches from "@/components/AiMatches";
import { ITEM_STATUSES, CLAIM_STATUSES } from "@/data/mockData";
import { deleteItem, formatDate, getItem, isItemOwner, updateItem } from "@/lib/store";

export const Route = createFileRoute("/item/$id")({
  head: () => ({
    meta: [
      { title: "Item Details | LostFound+" },
      {
        name: "description",
        content: "View full details of a reported lost or found item and submit a claim.",
      },
      { property: "og:title", content: "Item Details | LostFound+" },
      {
        property: "og:description",
        content: "Full report details, location, date and verified claim submission.",
      },
    ],
  }),
  component: ItemDetails,
});

function Row({ icon: Icon, label, value }) {
  if (!value) return null;
  return (
    <div className="flex min-w-0 items-start gap-3 rounded-lg border border-border bg-background px-4 py-3">
      <span className="grid size-8 shrink-0 place-items-center rounded-md bg-primary-soft text-primary">
        <Icon className="size-4" />
      </span>
      <div className="min-w-0">
        <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          {label}
        </p>
        <p className="mt-0.5 break-words text-sm font-medium text-foreground">{value}</p>
      </div>
    </div>
  );
}

function ItemDetails() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const [item, setItem] = useState(undefined); // undefined = loading, null = not found
  const [error, setError] = useState("");
  const [owner, setOwner] = useState(false);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const load = async () => {
    try {
      const data = await getItem(id);
      setItem(data);
      setOwner(isItemOwner(data));
    } catch (err) {
      setError(err.message || "Could not load this item.");
      setItem(null);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const handleFieldUpdate = async (field, value) => {
    setSaving(true);
    try {
      const updated = await updateItem(id, { [field]: value });
      setItem(updated);
    } catch (err) {
      setError(err.message || "Could not update this item.");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (typeof window !== "undefined" && !window.confirm("Delete this report? This can't be undone.")) {
      return;
    }
    setDeleting(true);
    try {
      await deleteItem(id);
      navigate({ to: "/dashboard" });
    } catch (err) {
      setError(err.message || "Could not delete this item.");
      setDeleting(false);
    }
  };

  if (item === undefined) {
    return (
      <div className="flex items-center justify-center gap-2 px-4 py-24 text-sm text-muted-foreground">
        <Loader2 className="size-4 animate-spin" /> Loading item…
      </div>
    );
  }

  if (!item) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 sm:px-6">
        <EmptyState
          icon={PackageSearch}
          title="Item Not Found"
          description={
            error || `We couldn't find a report with the ID "${id}". It may have been closed or removed.`
          }
          action={
            <Link
              to="/search"
              className="inline-flex items-center justify-center gap-2 rounded-md bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
            >
              <ArrowLeft className="size-4" /> Back to Search
            </Link>
          }
        />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:py-12">
      <Link
        to="/search"
        className="inline-flex items-center gap-2 text-sm font-semibold text-muted-foreground transition-colors hover:text-primary"
      >
        <ArrowLeft className="size-4" /> Back to Search
      </Link>

      <div className="mt-6 grid gap-8 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,1fr)]">
        <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-card">
          {item.imageUrl ? (
            <img
              src={item.imageUrl}
              alt={item.title}
              className="max-h-[26rem] w-full bg-muted object-cover"
            />
          ) : (
            <div className="grid h-72 place-items-center bg-muted text-sm text-muted-foreground">
              No image provided
            </div>
          )}
        </div>

        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <StatusBadge value={item.type} />
            <StatusBadge value={item.status} />
            {item.claimStatus && item.claimStatus !== "none" ? (
              <StatusBadge value={item.claimStatus} />
            ) : null}
          </div>
          <h1 className="mt-3 text-3xl font-bold tracking-tight text-foreground">{item.title}</h1>
          <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{item.description}</p>

          <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-2">
            <Row icon={Tag} label="Category" value={item.category} />
            <Row icon={MapPin} label="Location" value={item.location} />
            <Row
              icon={CalendarDays}
              label={item.type === "lost" ? "Date Lost" : "Date Found"}
              value={formatDate(item.date)}
            />
            <Row icon={Hash} label="Report ID" value={item.id} />
            <Row icon={Palette} label="Color / Brand" value={[item.color, item.brand].filter(Boolean).join(" · ")} />
            <Row
              icon={Coins}
              label="Reward"
              value={item.rewardAmount ? `₹${item.rewardAmount}` : null}
            />
          </div>

          <div className="mt-4 rounded-lg border border-border bg-background px-4 py-4">
            <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              <UserRound className="size-4" /> Reported by
            </p>
            <p className="mt-1.5 text-sm font-semibold text-foreground">
              {item.reportedBy?.name ?? "Campus Help Desk"}
            </p>
            <p className="text-sm text-muted-foreground">{item.reportedBy?.email ?? "—"}</p>
            <p className="mt-3 flex items-start gap-2 text-xs text-muted-foreground">
              <ShieldCheck className="mt-0.5 size-4 shrink-0 text-success" />
              Contact details are shared for verification purposes only. Always arrange handovers
              through the campus help desk.
            </p>
          </div>

          {owner ? (
            <div className="mt-6 rounded-xl border border-border bg-card p-5 shadow-card">
              <h2 className="text-sm font-semibold text-foreground">Manage this report</h2>
              <p className="mt-1 text-xs text-muted-foreground">
                You reported this item, so you can update its status or remove it.
              </p>
              <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    Status
                  </label>
                  <select
                    className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
                    value={item.status}
                    disabled={saving}
                    onChange={(e) => handleFieldUpdate("status", e.target.value)}
                  >
                    {ITEM_STATUSES.map((s) => (
                      <option key={s.value} value={s.value}>
                        {s.label}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    Claim status
                  </label>
                  <select
                    className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
                    value={item.claimStatus}
                    disabled={saving}
                    onChange={(e) => handleFieldUpdate("claimStatus", e.target.value)}
                  >
                    {CLAIM_STATUSES.map((s) => (
                      <option key={s.value} value={s.value}>
                        {s.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <button
                type="button"
                onClick={handleDelete}
                disabled={deleting}
                className="mt-4 inline-flex items-center gap-2 rounded-md border border-error/30 bg-error-soft px-4 py-2 text-sm font-semibold text-error transition-colors hover:bg-error/15 disabled:opacity-60"
              >
                {deleting ? <Loader2 className="size-4 animate-spin" /> : <Trash2 className="size-4" />}
                Delete Report
              </button>
              {error ? <p className="mt-3 text-sm text-error">{error}</p> : null}
            </div>
          ) : (
            <div className="mt-6 flex flex-col gap-3 sm:flex-row">
              <Link
                to="/claim/$id"
                params={{ id: item.id }}
                className="inline-flex flex-1 items-center justify-center rounded-md bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
              >
                Claim This Item
              </Link>
              <Link
                to="/search"
                className="inline-flex flex-1 items-center justify-center rounded-md border border-border bg-background px-5 py-3 text-sm font-semibold text-foreground transition-colors hover:bg-muted"
              >
                Back to Search
              </Link>
            </div>
          )}
        </div>
      </div>

      <div className="mt-8">
        <AiMatches item={item} isOwner={owner} onItemUpdated={setItem} />
      </div>
    </div>
  );
}
