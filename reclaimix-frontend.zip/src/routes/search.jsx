import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Loader2, Search } from "lucide-react";
import ItemCard from "@/components/ItemCard";
import SearchFilters from "@/components/SearchFilters";
import EmptyState from "@/components/EmptyState";
import { listItems } from "@/lib/store";

export const Route = createFileRoute("/search")({
  head: () => ({
    meta: [
      { title: "Search Lost & Found Items | LostFound+" },
      {
        name: "description",
        content:
          "Search every reported lost and found item on campus and filter by category, location and status.",
      },
      { property: "og:title", content: "Search Lost & Found Items | LostFound+" },
      {
        property: "og:description",
        content: "Filter campus lost and found listings by category, location and status.",
      },
    ],
  }),
  component: SearchItems,
});

const EMPTY_FILTERS = { type: "", category: "", location: "", status: "" };

function SearchItems() {
  const [query, setQuery] = useState("");
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError("");

    // Debounce the free-text query slightly so we don't hit the API on
    // every keystroke; other filters refetch immediately.
    const timer = setTimeout(
      async () => {
        try {
          const results = await listItems({ ...filters, search: query.trim() });
          if (!cancelled) setItems(results);
        } catch (err) {
          if (!cancelled) setError(err.message || "Could not load items.");
        } finally {
          if (!cancelled) setLoading(false);
        }
      },
      query ? 300 : 0,
    );

    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [query, filters]);

  const activeCount = Object.values(filters).filter(Boolean).length + (query.trim() ? 1 : 0);

  const clearAll = () => {
    setFilters(EMPTY_FILTERS);
    setQuery("");
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:py-14">
      <header className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Find an Item</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Search across every lost and found report submitted on campus.
        </p>

        <div className="relative mt-6">
          <Search className="pointer-events-none absolute left-4 top-1/2 size-5 -translate-y-1/2 text-muted-foreground" />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search lost or found items..."
            aria-label="Search lost or found items"
            className="w-full rounded-xl border border-border bg-card py-4 pl-12 pr-4 text-base text-foreground shadow-card outline-none transition-colors placeholder:text-muted-foreground focus:border-primary focus:ring-2 focus:ring-primary/20"
          />
        </div>
      </header>

      <div className="grid gap-6 lg:grid-cols-[280px_minmax(0,1fr)]">
        <div className="min-w-0">
          <SearchFilters
            filters={filters}
            onChange={setFilters}
            onClear={clearAll}
            activeCount={activeCount}
          />
        </div>

        <div className="min-w-0">
          <div className="mb-4 grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
            <p className="truncate text-sm text-muted-foreground">
              <span className="font-semibold text-foreground">{items.length}</span>{" "}
              {items.length === 1 ? "item" : "items"} found
              {activeCount ? " with current filters" : ""}
            </p>
            {activeCount ? (
              <button
                type="button"
                onClick={clearAll}
                className="shrink-0 rounded-md border border-border bg-card px-3 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-muted"
              >
                Clear Filters
              </button>
            ) : null}
          </div>

          {loading ? (
            <div className="flex items-center justify-center gap-2 rounded-xl border border-dashed border-border bg-card py-16 text-sm text-muted-foreground">
              <Loader2 className="size-4 animate-spin" /> Loading items…
            </div>
          ) : error ? (
            <EmptyState title="Couldn't load items" description={error} />
          ) : items.length ? (
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-3">
              {items.map((item) => (
                <ItemCard key={item.id} item={item} />
              ))}
            </div>
          ) : (
            <EmptyState
              action={
                <div className="flex flex-col gap-3 sm:flex-row">
                  <button
                    type="button"
                    onClick={clearAll}
                    className="inline-flex items-center justify-center rounded-md border border-border bg-background px-4 py-2 text-sm font-semibold text-foreground transition-colors hover:bg-muted"
                  >
                    Clear Filters
                  </button>
                  <Link
                    to="/report"
                    className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
                  >
                    Report an Item
                  </Link>
                </div>
              }
            />
          )}
        </div>
      </div>
    </div>
  );
}
