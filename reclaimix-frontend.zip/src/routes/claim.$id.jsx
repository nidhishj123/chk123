import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, CheckCircle2, Loader2, LogIn, Mail, PackageSearch } from "lucide-react";
import ImageUploader from "@/components/ImageUploader";
import StatusBadge from "@/components/StatusBadge";
import EmptyState from "@/components/EmptyState";
import {
  buildClaimMailto,
  formatDate,
  getCurrentUser,
  getItem,
  isAuthenticated,
  isItemOwner,
  saveClaimLocal,
  uploadImage,
} from "@/lib/store";

export const Route = createFileRoute("/claim/$id")({
  head: () => ({
    meta: [
      { title: "Submit a Claim | LostFound+" },
      {
        name: "description",
        content:
          "Submit a verified ownership claim for a found item with proof and identifying details.",
      },
      { property: "og:title", content: "Submit a Claim | LostFound+" },
      {
        property: "og:description",
        content: "Provide proof of ownership and track your claim status on LostFound+.",
      },
    ],
  }),
  component: ClaimItem,
});

const inputClass =
  "w-full rounded-md border border-border bg-background px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none transition-colors focus:border-primary focus:ring-2 focus:ring-primary/20";
const errorClass = "border-error focus:border-error focus:ring-error/20";

const EMPTY = {
  reason: "",
  uniqueFeature: "",
  lostLocation: "",
  lostDate: "",
  additional: "",
};

function Field({ label, required, error, children, htmlFor }) {
  return (
    <div className="min-w-0">
      <label htmlFor={htmlFor} className="mb-1.5 block text-sm font-medium text-foreground">
        {label} {required ? <span className="text-error">*</span> : null}
      </label>
      {children}
      {error ? <p className="mt-1.5 text-sm text-error">{error}</p> : null}
    </div>
  );
}

function ClaimItem() {
  const { id } = Route.useParams();
  const [item, setItem] = useState(undefined);
  const [signedIn, setSignedIn] = useState(false);
  const [owner, setOwner] = useState(false);
  const [authChecked, setAuthChecked] = useState(false);

  const [form, setForm] = useState(EMPTY);
  const [proof, setProof] = useState(null);
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState("");
  const [claim, setClaim] = useState(null);
  const [mailtoHref, setMailtoHref] = useState("");

  useEffect(() => {
    (async () => {
      const data = await getItem(id);
      setItem(data);
      setOwner(isItemOwner(data));
      setSignedIn(isAuthenticated());
      setAuthChecked(true);
    })();
  }, [id]);

  const set = (key) => (e) => {
    setForm((f) => ({ ...f, [key]: e.target.value }));
    setErrors((prev) => ({ ...prev, [key]: "" }));
  };

  if (item === undefined || !authChecked) {
    return (
      <div className="flex items-center justify-center gap-2 px-4 py-24 text-sm text-muted-foreground">
        <Loader2 className="size-4 animate-spin" /> Loading…
      </div>
    );
  }

  if (!item) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 sm:px-6">
        <EmptyState
          icon={PackageSearch}
          title="Item Not Found"
          description={`We couldn't find a report with the ID "${id}", so no claim can be submitted.`}
          action={
            <Link
              to="/search"
              className="inline-flex items-center justify-center gap-2 rounded-md bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
            >
              <ArrowLeft className="size-4" /> Back to Search
            </Link>
          }
        />
      </div>
    );
  }

  if (!signedIn) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 sm:px-6">
        <div className="rounded-2xl border border-border bg-card p-8 text-center shadow-card">
          <span className="mx-auto grid size-14 place-items-center rounded-full bg-primary-soft text-primary">
            <LogIn className="size-7" />
          </span>
          <h1 className="mt-5 text-2xl font-bold tracking-tight text-foreground">
            Sign in to submit a claim
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            We use your account details to identify you to the reporter.
          </p>
          <div className="mt-7 flex flex-col gap-3 sm:flex-row sm:justify-center">
            <Link
              to="/login"
              className="inline-flex items-center justify-center rounded-md bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
            >
              Sign in
            </Link>
            <Link
              to="/item/$id"
              params={{ id: item.id }}
              className="inline-flex items-center justify-center rounded-md border border-border bg-background px-5 py-2.5 text-sm font-semibold text-foreground transition-colors hover:bg-muted"
            >
              Back to item
            </Link>
          </div>
        </div>
      </div>
    );
  }

  if (owner) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 sm:px-6">
        <EmptyState
          icon={PackageSearch}
          title="This is your own report"
          description="You reported this item, so you can manage its status directly from the item page or your dashboard instead of filing a claim."
          action={
            <Link
              to="/item/$id"
              params={{ id: item.id }}
              className="inline-flex items-center justify-center gap-2 rounded-md bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
            >
              <ArrowLeft className="size-4" /> Go to item
            </Link>
          }
        />
      </div>
    );
  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    const next = {};
    if (form.reason.trim().length < 20)
      next.reason = "Please explain in at least 20 characters.";
    if (form.uniqueFeature.trim().length < 10)
      next.uniqueFeature = "Describe an identifying feature (10+ characters).";
    if (!form.lostLocation.trim()) next.lostLocation = "This field is required.";
    if (!form.lostDate) next.lostDate = "Select the date you lost the item.";
    setErrors(next);
    if (Object.keys(next).length) return;

    setSubmitting(true);
    setSubmitError("");
    try {
      let proofUrl = "";
      if (proof?.file) {
        proofUrl = await uploadImage(proof.file);
      }

      const cleanForm = {
        ...form,
        reason: form.reason.trim(),
        uniqueFeature: form.uniqueFeature.trim(),
        lostLocation: form.lostLocation.trim(),
        additional: form.additional.trim(),
        proofImage: proofUrl,
      };

      const saved = saveClaimLocal(item, cleanForm);
      const href = buildClaimMailto(item, cleanForm, getCurrentUser());
      setMailtoHref(href);
      setClaim(saved);
      if (typeof window !== "undefined") window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (err) {
      setSubmitError(err.message || "Could not submit the claim.");
    } finally {
      setSubmitting(false);
    }
  };

  if (claim) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 sm:px-6">
        <div className="rounded-2xl border border-border bg-card p-8 text-center shadow-card">
          <span className="mx-auto grid size-14 place-items-center rounded-full bg-success-soft text-success">
            <CheckCircle2 className="size-7" />
          </span>
          <h1 className="mt-5 text-2xl font-bold tracking-tight text-foreground">
            Claim details ready
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Your claim for <span className="font-semibold text-foreground">{item.title}</span> has
            been saved to your dashboard. Send it to the reporter to complete the handover.
          </p>
          <a
            href={mailtoHref}
            className="mt-6 inline-flex items-center justify-center gap-2 rounded-md bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
          >
            <Mail className="size-4" /> Email the reporter
          </a>
          <div className="mt-6 grid gap-3 sm:grid-cols-2">
            <div className="rounded-lg border border-border bg-background px-4 py-4">
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Claim reference
              </p>
              <p className="mt-1 text-lg font-bold tracking-tight text-primary">{claim.id}</p>
            </div>
            <div className="rounded-lg border border-border bg-background px-4 py-4">
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Status
              </p>
              <p className="mt-2">
                <StatusBadge value="pending" />
              </p>
            </div>
          </div>
          <div className="mt-7 flex flex-col gap-3 sm:flex-row sm:justify-center">
            <Link
              to="/dashboard"
              className="inline-flex items-center justify-center rounded-md border border-border bg-background px-5 py-2.5 text-sm font-semibold text-foreground transition-colors hover:bg-muted"
            >
              View My Claims
            </Link>
            <Link
              to="/search"
              className="inline-flex items-center justify-center rounded-md border border-border bg-background px-5 py-2.5 text-sm font-semibold text-foreground transition-colors hover:bg-muted"
            >
              Continue Searching
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 lg:py-14">
      <Link
        to="/item/$id"
        params={{ id: item.id }}
        className="inline-flex items-center gap-2 text-sm font-semibold text-muted-foreground transition-colors hover:text-primary"
      >
        <ArrowLeft className="size-4" /> Back to item
      </Link>

      <h1 className="mt-5 text-3xl font-bold tracking-tight text-foreground">Claim This Item</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        Provide details only the real owner would know. We'll prepare an email to the reporter
        with your details for verification.
      </p>

      <section className="mt-6 grid grid-cols-[auto_minmax(0,1fr)] items-center gap-4 rounded-xl border border-border bg-card p-4 shadow-card">
        <div className="size-20 shrink-0 overflow-hidden rounded-lg bg-muted">
          {item.imageUrl ? (
            <img src={item.imageUrl} alt={item.title} className="size-full object-cover" />
          ) : null}
        </div>
        <div className="min-w-0">
          <h2 className="truncate text-base font-semibold text-foreground">{item.title}</h2>
          <p className="mt-1 truncate text-sm text-muted-foreground">
            {item.category || "Uncategorised"} · {item.location} · {formatDate(item.date)}
          </p>
          <div className="mt-2 flex flex-wrap gap-2">
            <StatusBadge value={item.type} />
            <StatusBadge value={item.status} />
          </div>
        </div>
      </section>

      <form
        onSubmit={handleSubmit}
        noValidate
        className="mt-6 space-y-6 rounded-2xl border border-border bg-card p-6 shadow-card sm:p-8"
      >
        <Field
          label="Why do you believe this item is yours?"
          required
          error={errors.reason}
          htmlFor="reason"
        >
          <textarea
            id="reason"
            rows={4}
            maxLength={600}
            className={`${inputClass} resize-y ${errors.reason ? errorClass : ""}`}
            placeholder="Explain your connection to the item…"
            value={form.reason}
            onChange={set("reason")}
          />
        </Field>

        <Field
          label="Describe a unique identifying feature"
          required
          error={errors.uniqueFeature}
          htmlFor="uniqueFeature"
        >
          <textarea
            id="uniqueFeature"
            rows={3}
            maxLength={400}
            className={`${inputClass} resize-y ${errors.uniqueFeature ? errorClass : ""}`}
            placeholder="A scratch, sticker, engraving, lock screen, contents…"
            value={form.uniqueFeature}
            onChange={set("uniqueFeature")}
          />
        </Field>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
          <Field
            label="Where did you lose the item?"
            required
            error={errors.lostLocation}
            htmlFor="lostLocation"
          >
            <input
              id="lostLocation"
              className={`${inputClass} ${errors.lostLocation ? errorClass : ""}`}
              placeholder="e.g. Central Library, 2nd floor"
              value={form.lostLocation}
              onChange={set("lostLocation")}
            />
          </Field>

          <Field
            label="When did you lose the item?"
            required
            error={errors.lostDate}
            htmlFor="lostDate"
          >
            <input
              id="lostDate"
              type="date"
              className={`${inputClass} ${errors.lostDate ? errorClass : ""}`}
              value={form.lostDate}
              onChange={set("lostDate")}
            />
          </Field>
        </div>

        <Field label="Additional information" htmlFor="additional">
          <textarea
            id="additional"
            rows={3}
            maxLength={400}
            className={`${inputClass} resize-y`}
            placeholder="Anything else that supports your claim (optional)"
            value={form.additional}
            onChange={set("additional")}
          />
        </Field>

        <ImageUploader
          value={proof}
          onChange={setProof}
          label="Proof image (optional)"
          hint="A photo of the item in your possession, receipt or packaging"
        />

        {submitError ? <p className="text-sm text-error">{submitError}</p> : null}

        <div className="flex flex-col gap-3 border-t border-border pt-6 sm:flex-row sm:justify-end">
          <Link
            to="/item/$id"
            params={{ id: item.id }}
            className="inline-flex items-center justify-center rounded-md border border-border bg-background px-5 py-2.5 text-sm font-semibold text-foreground transition-colors hover:bg-muted"
          >
            Cancel
          </Link>
          <button
            type="submit"
            disabled={submitting}
            className="inline-flex items-center justify-center gap-2 rounded-md bg-primary px-6 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-60"
          >
            {submitting ? <Loader2 className="size-4 animate-spin" /> : null}
            Submit Claim
          </button>
        </div>
      </form>
    </div>
  );
}
