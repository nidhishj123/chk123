import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ClipboardList,
  FileCheck2,
  Inbox,
  LogIn,
  Loader2,
  PackageSearch,
  TimerReset,
  ArrowDownLeft,
  ArrowUpRight,
} from "lucide-react";
import StatCard from "@/components/StatCard";
import StatusBadge from "@/components/StatusBadge";
import EmptyState from "@/components/EmptyState";
import { formatDate, getCurrentUser, isAuthenticated, listMyClaimsLocal, listMyReports } from "@/lib/store";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "My Dashboard | LostFound+" },
      {
        name: "description",
        content: "Track your lost and found reports and the status of every claim you submitted.",
      },
      { property: "og:title", content: "My Dashboard | LostFound+" },
      {
        property: "og:description",
        content: "All your LostFound+ reports and claims in one place.",
      },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const [authChecked, setAuthChecked] = useState(false);
  const [signedIn, setSignedIn] = useState(false);
  const [user, setUser] = useState(null);
  const [tab, setTab] = useState("reports");
  const [reports, setReports] = useState([]);
  const [claims, setClaims] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const ok = isAuthenticated();
    setSignedIn(ok);
    setUser(getCurrentUser());
    setAuthChecked(true);
    if (!ok) {
      setLoading(false);
      return;
    }
    (async () => {
      try {
        const [myReports] = await Promise.all([listMyReports()]);
        setReports(myReports);
        setClaims(listMyClaimsLocal());
      } catch (err) {
        setError(err.message || "Could not load your dashboard.");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (!authChecked || loading) {
    return (
      <div className="flex items-center justify-center gap-2 px-4 py-24 text-sm text-muted-foreground">
        <Loader2 className="size-4 animate-spin" /> Loading dashboard…
      </div>
    );
  }

  if (!signedIn) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 sm:px-6">
        <div className="rounded-2xl border border-border bg-card p-8 text-center shadow-card">
          <span className="mx-auto grid size-14 place-items-center rounded-full bg-primary-soft text-primary">
            <LogIn className="size-7" />
          </span>
          <h1 className="mt-5 text-2xl font-bold tracking-tight text-foreground">
            Sign in to view your dashboard
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Track your reports and claims once you're signed in.
          </p>
          <div className="mt-7 flex flex-col gap-3 sm:flex-row sm:justify-center">
            <Link
              to="/login"
              className="inline-flex items-center justify-center rounded-md bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
            >
              Sign in
            </Link>
            <Link
              to="/register"
              className="inline-flex items-center justify-center rounded-md border border-border bg-background px-5 py-2.5 text-sm font-semibold text-foreground transition-colors hover:bg-muted"
            >
              Create an account
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const lost = reports.filter((r) => r.type === "lost").length;
  const found = reports.filter((r) => r.type === "found").length;
  const pending = claims.filter((c) => c.status === "Pending").length;

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:py-14">
      <header className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4">
        <div className="min-w-0">
          <h1 className="truncate text-3xl font-bold tracking-tight text-foreground">
            My Dashboard
          </h1>
          <p className="mt-2 truncate text-sm text-muted-foreground">
            Signed in as {user?.name} · {user?.email}
          </p>
        </div>
        <Link
          to="/report"
          className="inline-flex shrink-0 items-center justify-center rounded-md bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
        >
          New Report
        </Link>
      </header>

      {error ? <p className="mt-4 text-sm text-error">{error}</p> : null}

      <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-5">
        <StatCard icon={ClipboardList} label="Total Reports" value={reports.length} />
        <StatCard icon={ArrowUpRight} label="Lost Reports" value={lost} />
        <StatCard icon={ArrowDownLeft} label="Found Reports" value={found} />
        <StatCard icon={FileCheck2} label="Total Claims" value={claims.length} />
        <StatCard icon={TimerReset} label="Pending Claims" value={pending} />
      </div>

      <div className="mt-10 inline-flex rounded-lg border border-border bg-card p-1">
        {[
          { key: "reports", label: "My Reports" },
          { key: "claims", label: "My Claims" },
        ].map((t) => (
          <button
            key={t.key}
            type="button"
            onClick={() => setTab(t.key)}
            aria-pressed={tab === t.key}
            className={`rounded-md px-4 py-2 text-sm font-semibold transition-colors ${
              tab === t.key
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:bg-muted"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="mt-6">
        {tab === "reports" ? (
          reports.length ? (
            <ul className="space-y-4">
              {reports.map((r) => (
                <li
                  key={r.id}
                  className="grid grid-cols-[auto_minmax(0,1fr)] items-start gap-4 rounded-xl border border-border bg-card p-4 shadow-card sm:grid-cols-[auto_minmax(0,1fr)_auto] sm:items-center"
                >
                  <div className="size-20 shrink-0 overflow-hidden rounded-lg bg-muted">
                    {r.imageUrl ? (
                      <img src={r.imageUrl} alt={r.title} className="size-full object-cover" />
                    ) : (
                      <div className="grid size-full place-items-center text-xs text-muted-foreground">
                        No image
                      </div>
                    )}
                  </div>
                  <div className="min-w-0">
                    <h3 className="truncate text-base font-semibold text-foreground">{r.title}</h3>
                    <p className="mt-1 truncate text-sm text-muted-foreground">
                      {r.category || "Uncategorised"} · {r.location} · {formatDate(r.date)}
                    </p>
                    <div className="mt-2 flex flex-wrap gap-2">
                      <StatusBadge value={r.type} />
                      <StatusBadge value={r.status} />
                      <span className="text-xs text-muted-foreground">{r.id}</span>
                    </div>
                  </div>
                  <Link
                    to="/item/$id"
                    params={{ id: r.id }}
                    className="col-span-2 inline-flex items-center justify-center rounded-md border border-border bg-background px-4 py-2 text-sm font-semibold text-foreground transition-colors hover:border-primary/40 hover:bg-primary-soft hover:text-primary sm:col-span-1"
                  >
                    Manage
                  </Link>
                </li>
              ))}
            </ul>
          ) : (
            <EmptyState
              icon={PackageSearch}
              title="No reports yet"
              description="Reports you submit will appear here so you can track their status."
              action={
                <Link
                  to="/report"
                  className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
                >
                  Report an Item
                </Link>
              }
            />
          )
        ) : claims.length ? (
          <>
            <p className="mb-4 text-xs text-muted-foreground">
              Claims are saved on this device and emailed to the reporter — the backend doesn't
              have a shared claims database yet.
            </p>
            <ul className="space-y-4">
              {claims.map((c) => (
                <li
                  key={c.id}
                  className="grid grid-cols-[auto_minmax(0,1fr)] items-start gap-4 rounded-xl border border-border bg-card p-4 shadow-card sm:grid-cols-[auto_minmax(0,1fr)_auto] sm:items-center"
                >
                  <div className="size-20 shrink-0 overflow-hidden rounded-lg bg-muted">
                    {c.itemImage ? (
                      <img src={c.itemImage} alt={c.itemTitle} className="size-full object-cover" />
                    ) : (
                      <div className="grid size-full place-items-center text-xs text-muted-foreground">
                        No image
                      </div>
                    )}
                  </div>
                  <div className="min-w-0">
                    <h3 className="truncate text-base font-semibold text-foreground">
                      {c.itemTitle}
                    </h3>
                    <p className="mt-1 truncate text-sm text-muted-foreground">
                      Claim ref {c.id} · Submitted {formatDate(c.submittedAt)}
                    </p>
                    <div className="mt-2">
                      <StatusBadge value="pending" />
                    </div>
                  </div>
                  <Link
                    to="/item/$id"
                    params={{ id: c.itemId }}
                    className="col-span-2 inline-flex items-center justify-center rounded-md border border-border bg-background px-4 py-2 text-sm font-semibold text-foreground transition-colors hover:border-primary/40 hover:bg-primary-soft hover:text-primary sm:col-span-1"
                  >
                    View Item
                  </Link>
                </li>
              ))}
            </ul>
          </>
        ) : (
          <EmptyState
            icon={Inbox}
            title="No claims yet"
            description="When you claim a found item, it will show up here."
            action={
              <Link
                to="/search"
                className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
              >
                Find an Item
              </Link>
            }
          />
        )}
      </div>
    </div>
  );
}
