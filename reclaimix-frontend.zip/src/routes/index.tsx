import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  BadgeCheck,
  ClipboardList,
  FileSearch,
  HandHeart,
  PackageCheck,
  ShieldCheck,
  Sparkles,
  TrendingUp,
} from "lucide-react";
import StatCard from "@/components/StatCard";
import { PLATFORM_STATS } from "@/data/mockData";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "LostFound+ | Report, Search and Reclaim Lost Items" },
      {
        name: "description",
        content:
          "Lost something on campus? Found something? LostFound+ connects reports with owners through verified claims.",
      },
      { property: "og:title", content: "LostFound+ | Report, Search and Reclaim Lost Items" },
      {
        property: "og:description",
        content: "A trusted campus lost & found platform with verified claim tracking.",
      },
    ],
  }),
  component: Home,
});

const STEPS = [
  {
    icon: ClipboardList,
    title: "Report",
    text: "Submit a lost or found item with photos, location and date in under a minute.",
  },
  {
    icon: FileSearch,
    title: "Search",
    text: "Browse live listings and filter by category, location, date and status.",
  },
  {
    icon: ShieldCheck,
    title: "Verify",
    text: "Owners submit proof of ownership so every handover is checked before approval.",
  },
  {
    icon: HandHeart,
    title: "Reclaim",
    text: "Once approved, collect the item from the help desk and the listing is closed.",
  },
];

function Home() {
  return (
    <>
      <section className="border-b border-border bg-card">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:py-24">
          <div className="min-w-0">
            <span className="inline-flex items-center gap-2 rounded-full border border-border bg-primary-soft px-3 py-1 text-xs font-semibold text-primary">
              <Sparkles className="size-3.5" /> Campus Lost &amp; Found Management
            </span>
            <h1 className="mt-5 text-4xl font-bold leading-tight tracking-tight text-foreground sm:text-5xl">
              Lost something? Found something?{" "}
              <span className="text-primary">Help it find its way home.</span>
            </h1>
            <p className="mt-5 max-w-xl text-base leading-relaxed text-muted-foreground">
              LostFound+ replaces scattered notice boards and group chats with one organised
              system. Post a report in seconds, search everything reported across campus, and
              recover belongings through a verified claim process that protects everyone involved.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link
                to="/search"
                className="inline-flex items-center justify-center gap-2 rounded-md bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground shadow-card transition-colors hover:bg-primary/90"
              >
                Find an Item <ArrowRight className="size-4" />
              </Link>
              <Link
                to="/report"
                className="inline-flex items-center justify-center gap-2 rounded-md border border-border bg-background px-5 py-3 text-sm font-semibold text-foreground transition-colors hover:border-primary/40 hover:bg-primary-soft hover:text-primary"
              >
                Report an Item
              </Link>
            </div>
            <p className="mt-5 flex items-center gap-2 text-sm text-muted-foreground">
              <BadgeCheck className="size-4 text-success" />
              863 items already returned to their owners this year.
            </p>
          </div>

          <div className="relative min-w-0">
            <div className="overflow-hidden rounded-2xl border border-border shadow-card-hover">
              <img
                src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1200&q=70"
                alt="Students collaborating at a campus help desk"
                className="h-72 w-full object-cover sm:h-96"
              />
            </div>
            <div className="absolute -bottom-6 left-4 hidden rounded-xl border border-border bg-card p-4 shadow-card-hover sm:block">
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Recovery rate
              </p>
              <p className="mt-1 flex items-center gap-2 text-2xl font-bold text-foreground">
                69% <TrendingUp className="size-5 text-success" />
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard
            icon={ClipboardList}
            label="Total Reports"
            value={PLATFORM_STATS.totalReports.toLocaleString()}
            hint="Lost and found submissions"
          />
          <StatCard
            icon={PackageCheck}
            label="Items Recovered"
            value={PLATFORM_STATS.itemsRecovered.toLocaleString()}
            hint="Returned to verified owners"
          />
          <StatCard
            icon={FileSearch}
            label="Active Listings"
            value={PLATFORM_STATS.activeListings.toLocaleString()}
            hint="Currently open on the board"
          />
          <StatCard
            icon={BadgeCheck}
            label="Successful Claims"
            value={PLATFORM_STATS.successfulClaims.toLocaleString()}
            hint="Approved after verification"
          />
        </div>
      </section>

      <section className="border-y border-border bg-card">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
          <div className="max-w-2xl">
            <h2 className="text-3xl font-bold tracking-tight text-foreground">How it works</h2>
            <p className="mt-3 text-muted-foreground">
              Four simple steps keep every item accounted for — from the moment it goes missing to
              the moment it is back with its owner.
            </p>
          </div>
          <ol className="mt-10 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {STEPS.map((s, i) => (
              <li
                key={s.title}
                className="rounded-xl border border-border bg-background p-6 shadow-card"
              >
                <div className="flex items-center gap-3">
                  <span className="grid size-10 shrink-0 place-items-center rounded-lg bg-primary-soft text-primary">
                    <s.icon className="size-5" />
                  </span>
                  <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
                    Step {i + 1}
                  </span>
                </div>
                <h3 className="mt-4 text-lg font-semibold text-foreground">{s.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.text}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="grid gap-6 rounded-2xl border border-border bg-navy px-6 py-12 text-center sm:px-12">
          <h2 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">
            Something missing? Start with a report.
          </h2>
          <p className="mx-auto max-w-2xl text-sm text-slate-300">
            The faster an item is listed, the higher the chance someone recognises it. It takes less
            than a minute.
          </p>
          <div className="flex flex-col justify-center gap-3 sm:flex-row">
            <Link
              to="/report"
              className="inline-flex items-center justify-center gap-2 rounded-md bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
            >
              Report an Item <ArrowRight className="size-4" />
            </Link>
            <Link
              to="/dashboard"
              className="inline-flex items-center justify-center rounded-md border border-white/20 px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-white/10"
            >
              Go to My Dashboard
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
